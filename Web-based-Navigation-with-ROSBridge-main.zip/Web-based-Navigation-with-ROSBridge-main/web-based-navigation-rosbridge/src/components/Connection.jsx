

class Connection extends Component {
  
}

export default Connection;
