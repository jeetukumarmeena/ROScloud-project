class Body extends Component {
  
}

export default Body;
